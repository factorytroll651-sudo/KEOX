package com.vnx.gamehub

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.provider.Settings
import android.content.res.ColorStateList

/**
 * In-game slide-out panel. Every function is ONE slide switch: slide on = ON, slide again = OFF.
 * Tap the dark area outside the panel (or the X) to close it and go back to the game.
 */
class SidePanel(
    ctx: Context,
    private val right: Boolean,
    private val onClose: () -> Unit,
    private val onLock: () -> Unit
) : FrameLayout(ctx) {

    private val ui = Handler(Looper.getMainLooper())
    private val panel = LinearLayout(ctx)
    private val status = TextView(ctx)
    private var closing = false
    private val panelW = ctx.dp(270)
    private var scrollRef: View? = null

    init {
        setBackgroundColor(Color.argb(110, 0, 0, 0))
        alpha = 0f
        setOnClickListener { close() }

        panel.orientation = LinearLayout.VERTICAL
        panel.isClickable = true
        panel.setPadding(ctx.dp(14), ctx.dp(14), ctx.dp(14), ctx.dp(14))
        panel.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#F00B0714"), Color.parseColor("#F01A0B2E"))).apply {
            cornerRadii = if (right) floatArrayOf(ctx.dpf(22f), ctx.dpf(22f), 0f, 0f, 0f, 0f, ctx.dpf(22f), ctx.dpf(22f))
            else floatArrayOf(0f, 0f, ctx.dpf(22f), ctx.dpf(22f), ctx.dpf(22f), ctx.dpf(22f), 0f, 0f)
            setStroke(ctx.dp(1), Theme.PINK)
        }

        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(ctx).apply {
            text = "KEOX FF PANEL"; textSize = 15f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD); letterSpacing = 0.1f
        }
        val x = TextView(ctx).apply {
            text = "✕"; textSize = 18f; setTextColor(Theme.PINK); setPadding(ctx.dp(10), 0, 0, 0)
            setOnClickListener { close() }
        }
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); head.addView(x)
        panel.addView(head)

        row("GAME MODE", "DND + max brightness", Theme.GREEN, true, { Prefs.getBool(context, "game_on", false) }) {
            Tools.gameToggle(context) }
        row("BOOSTER", "faster animations", Theme.GOLD, false, { Prefs.getBool(context, "boost_on", false) }) {
            Tools.boostToggle(context) }
        row("SHOW TOUCHES", "touch points on screen", Theme.PINK, false, { Prefs.getBool(context, "touches_on", false) }) {
            Tools.touchesToggle(context) }
        row("SESSION LOG", "start / end play time", Theme.CYAN, false, { Prefs.getLong(context, "sess_start", 0L) > 0L }) {
            Tools.sessionToggle(context) }
        row("LOCK CIRCLE", "stay put, touch passes through", Theme.GOLD, true, { Prefs.getBool(context, "locked", false) }) {
            onLock(); if (Prefs.getBool(context, "locked", false)) "CIRCLE LOCKED" else "CIRCLE UNLOCKED" }

        panel.addView(brightnessRow())

        val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ctx.dp(10), 0, 0) }
        btns.addView(pill("SYSTEM", Theme.CYAN) { bg { Tools.system(context) } }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = ctx.dp(4) })
        btns.addView(pill("PING", Theme.PURPLE) { bg { Tools.network() } }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = ctx.dp(4) })
        panel.addView(btns)

        status.apply {
            typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Theme.GREEN)
            setPadding(ctx.dp(10), ctx.dp(8), ctx.dp(10), ctx.dp(8)); text = "> ready"
            background = GradientDrawable().apply { cornerRadius = ctx.dpf(12f); setColor(Color.parseColor("#CC050310")) }
        }
        panel.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(10) })

        val scroll = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; isFillViewport = true; addView(panel) }
        addView(scroll, LayoutParams(panelW, ViewGroup.LayoutParams.MATCH_PARENT, if (right) Gravity.END else Gravity.START))
        scrollRef = scroll
    }

    private fun row(title: String, sub: String, accent: Int, onMain: Boolean, state: () -> Boolean, action: () -> String) {
        val c = context
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(c.dp(12), c.dp(10), c.dp(12), c.dp(10))
            background = GradientDrawable().apply { cornerRadius = c.dpf(14f); setColor(Color.parseColor("#26FFFFFF")) }
        }
        val txt = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        txt.addView(TextView(c).apply {
            text = title; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        txt.addView(TextView(c).apply { text = sub; textSize = 10f; setTextColor(Color.parseColor("#A99CC8")) })
        val tg = SlideToggle(c, accent)
        tg.setChecked(state(), false)
        tg.onChange = { _ ->
            if (onMain) {
                say(try { action() } catch (e: Exception) { "[X] ${e.message}" })
                tg.setChecked(state(), true)
            } else {
                say("working...")
                Thread {
                    val r = try { action() } catch (e: Exception) { "[X] ${e.message}" }
                    ui.post { say(r); tg.setChecked(state(), true) }
                }.start()
            }
        }
        box.addView(txt, LinearLayout.LayoutParams(0, -2, 1f)); box.addView(tg)
        panel.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(10) })
    }

    private fun brightnessRow(): View {
        val c = context
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(c.dp(12), c.dp(10), c.dp(12), c.dp(8))
            background = GradientDrawable().apply { cornerRadius = c.dpf(14f); setColor(Color.parseColor("#26FFFFFF")) }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = c.dp(10) }
        }
        val cur = try {
            Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255
        } catch (e: Exception) { 50 }
        val tv = TextView(c).apply { text = "BRIGHTNESS  $cur%"; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        val sb = SeekBar(c).apply {
            max = 90; progress = (cur - 10).coerceIn(0, 90)
            progressTintList = ColorStateList.valueOf(Theme.GOLD)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = "BRIGHTNESS  ${p + 10}%"
                    if (fromUser) { val r = Tools.brightness(c, p + 10); if (r.startsWith("[X]")) say(r) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(tv); box.addView(sb)
        return box
    }

    private fun pill(text: String, accent: Int, click: () -> Unit): TextView = TextView(context).apply {
        this.text = text; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.1f
        setPadding(0, context.dp(10), 0, context.dp(10))
        background = GradientDrawable().apply {
            cornerRadius = context.dpf(20f); setColor(Color.parseColor("#22FFFFFF")); setStroke(context.dp(1), accent)
        }
        setOnClickListener { click() }
    }

    private fun bg(job: () -> String) {
        say("working...")
        Thread {
            val r = try { job() } catch (e: Exception) { "[X] ${e.message}" }
            ui.post { say(r) }
        }.start()
    }

    private fun say(t: String) { status.text = "> $t" }

    fun open() {
        val s = scrollRef ?: return
        s.translationX = if (right) panelW.toFloat() else -panelW.toFloat()
        s.animate().translationX(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        animate().alpha(1f).setDuration(200).start()
    }

    fun close() {
        if (closing) return
        closing = true
        val s = scrollRef
        s?.animate()?.translationX(if (right) panelW.toFloat() else -panelW.toFloat())
            ?.setDuration(200)?.setInterpolator(AccelerateInterpolator())?.start()
        animate().alpha(0f).setDuration(200).withEndAction { onClose() }.start()
    }
}
