package com.vnx.gamehub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import kotlin.math.abs

/**
 * Floating circle + edge handle + slide panel.
 *
 * - Circle (unlocked): drag anywhere, tap = open panel.
 * - Circle (locked): stays put and is click-through, so touches reach the game below.
 * - Edge handle: swipe it inward (or tap) to slide the panel in, even when the circle is locked.
 * - A watchdog re-adds the views if the system removed them (some phones do this when a game starts).
 */
class FloatingService : Service() {

    companion object {
        const val ACT_START = "com.vnx.gamehub.START"
        const val ACT_STOP = "com.vnx.gamehub.STOP"
        const val ACT_UPDATE = "com.vnx.gamehub.UPDATE"
        const val ACT_TOGGLE_LOCK = "com.vnx.gamehub.TOGGLE_LOCK"
        const val ACT_PANEL = "com.vnx.gamehub.PANEL"
        private const val CH = "vnx_circle"
        private const val NID = 7
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var circle: CircleView? = null
    private var chip: LockChip? = null
    private var handle: EdgeHandle? = null
    private var panel: SidePanel? = null
    private var cp: WindowManager.LayoutParams? = null
    private var lp: WindowManager.LayoutParams? = null
    private var hp: WindowManager.LayoutParams? = null
    private var handleRight = true

    private val watchdog = object : Runnable {
        override fun run() {
            val c = circle
            if (c != null && !c.isAttachedToWindow && Settings.canDrawOverlays(this@FloatingService)) {
                removeViews(); addViews()
            }
            ui.postDelayed(this, 3000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        when (intent?.action ?: ACT_START) {
            ACT_STOP -> { shutdown(); return START_NOT_STICKY }
            ACT_TOGGLE_LOCK -> { toggleLock() }
            ACT_PANEL -> { openPanel() }
            ACT_UPDATE -> { applyPrefs(); notifyFg() }
            else -> {
                if (!Settings.canDrawOverlays(this)) { shutdown(); return START_NOT_STICKY }
                notifyFg(); addViews(); Prefs.putBool(this, "circle_on", true)
                ui.removeCallbacks(watchdog); ui.postDelayed(watchdog, 3000)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        ui.removeCallbacks(watchdog)
        removeViews()
        super.onDestroy()
    }

    private fun shutdown() {
        Prefs.putBool(this, "circle_on", false)
        ui.removeCallbacks(watchdog)
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun toggleLock() {
        Prefs.putBool(this, "locked", !Prefs.getBool(this, "locked", false))
        buzz(); applyPrefs(); notifyFg()
    }

    private fun size() = Prefs.getInt(this, "size_dp", 64)
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun rightSide() = Prefs.getBool(this, "panel_right", true)

    private fun baseFlags(untouchable: Boolean): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (untouchable) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private fun addViews() {
        if (circle != null) { applyPrefs(); return }
        val px = dp(size())
        val locked = Prefs.getBool(this, "locked", false)

        val c = CircleView(this)
        val p1 = WindowManager.LayoutParams(px, px, overlayType(), baseFlags(locked), PixelFormat.TRANSLUCENT)
        p1.gravity = Gravity.TOP or Gravity.START
        p1.x = Prefs.getInt(this, "cx", dp(40)); p1.y = Prefs.getInt(this, "cy", dp(300))

        val chipPx = dp(40)
        val c2 = LockChip(this)
        val p2 = WindowManager.LayoutParams(chipPx, chipPx, overlayType(), baseFlags(false), PixelFormat.TRANSLUCENT)
        p2.gravity = Gravity.TOP or Gravity.START
        p2.x = Prefs.getInt(this, "lx", dp(14))
        p2.y = Prefs.getInt(this, "ly", (resources.displayMetrics.heightPixels * 0.2f).toInt())

        val right = rightSide()
        val h = EdgeHandle(this, right)
        val p3 = WindowManager.LayoutParams(dp(18), dp(110), overlayType(), baseFlags(false), PixelFormat.TRANSLUCENT)
        p3.gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START)
        p3.y = Prefs.getInt(this, "hy", (resources.displayMetrics.heightPixels * 0.35f).toInt())

        c.locked = locked; c2.locked = locked
        c.alpha = Prefs.getInt(this, "alpha_pct", 75) / 100f
        circle = c; chip = c2; handle = h; cp = p1; lp = p2; hp = p3; handleRight = right
        wm.addView(c, p1); wm.addView(c2, p2); wm.addView(h, p3)
        wireCircle(c)
        wireHandle(h)
        wireLock(c2)
    }

    private fun wireLock(v: LockChip) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            val p = lp ?: return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (abs(mx) > slop || abs(my) > slop) moved = true
                    if (moved) {
                        p.x = (sx + mx).toInt().coerceAtLeast(0)
                        p.y = (sy + my).toInt().coerceAtLeast(0)
                        wm.updateViewLayout(v, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { Prefs.putInt(this, "lx", p.x); Prefs.putInt(this, "ly", p.y) }
                    else toggleLock()
                }
            }
            true
        }
    }

    private fun wireCircle(v: CircleView) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            val p1 = cp ?: return@setOnTouchListener false
            if (Prefs.getBool(this, "locked", false)) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p1.x; sy = p1.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (abs(mx) > slop || abs(my) > slop) moved = true
                    if (moved) {
                        p1.x = (sx + mx).toInt().coerceAtLeast(0)
                        p1.y = (sy + my).toInt().coerceAtLeast(0)
                        wm.updateViewLayout(v, p1)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.putInt(this, "cx", p1.x); Prefs.putInt(this, "cy", p1.y)
                    } else {
                        v.pulse(); buzz(); openPanel()
                    }
                }
            }
            true
        }
    }

    private fun wireHandle(h: EdgeHandle) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0f; var sy = 0f; var startY = 0; var vertical = false; var opened = false
        h.setOnTouchListener { _, e ->
            val p = hp ?: return@setOnTouchListener false
            val right = rightSide()
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; startY = p.y; vertical = false; opened = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (!opened) {
                        val inward = if (right) -dx else dx
                        if (inward > dp(14)) { opened = true; buzz(); openPanel() }
                        else if (abs(dy) > slop && abs(dy) > abs(dx)) {
                            vertical = true
                            p.y = (startY + dy).toInt().coerceAtLeast(0)
                            wm.updateViewLayout(h, p)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (vertical) Prefs.putInt(this, "hy", p.y)
                    else if (!opened && abs(e.rawX - sx) < slop && abs(e.rawY - sy) < slop) { buzz(); openPanel() }
                }
            }
            true
        }
    }

    private fun openPanel() {
        if (panel != null || !Settings.canDrawOverlays(this)) return
        val sp = SidePanel(this, rightSide(), { removePanel() }, { toggleLock() })
        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        wm.addView(sp, params)
        panel = sp
        sp.open()
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun applyPrefs() {
        val c = circle ?: return; val p1 = cp ?: return; val c2 = chip ?: return
        val locked = Prefs.getBool(this, "locked", false)
        val px = dp(size())
        p1.width = px; p1.height = px
        p1.flags = baseFlags(locked)
        c.locked = locked; c2.locked = locked
        c.alpha = Prefs.getInt(this, "alpha_pct", 75) / 100f
        wm.updateViewLayout(c, p1)
        wm.updateViewLayout(c2, lp)

        val h = handle; val p3 = hp
        if (h != null && p3 != null && rightSide() != handleRight) {
            // side changed: rebuild the handle so its shape faces the right way
            try { wm.removeView(h) } catch (_: Exception) {}
            val right = rightSide()
            val nh = EdgeHandle(this, right)
            p3.gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START)
            wm.addView(nh, p3)
            handle = nh; handleRight = right
            wireHandle(nh)
        }
    }

    private fun removeViews() {
        removePanel()
        try { circle?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { chip?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { handle?.let { wm.removeView(it) } } catch (_: Exception) {}
        circle = null; chip = null; handle = null; cp = null; lp = null; hp = null
    }

    private fun buzz() {
        val v = getSystemService(Vibrator::class.java)
        v?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun pi(action: String, code: Int): PendingIntent =
        PendingIntent.getService(this, code, Intent(this, FloatingService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun notifyFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Keox Ff", NotificationManager.IMPORTANCE_LOW))
        val locked = Prefs.getBool(this, "locked", false)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Keox Ff is ON")
            .setContentText(if (locked) "Circle locked: touches pass through" else "Circle unlocked: drag to move")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_lock_lock),
                if (locked) "UNLOCK" else "LOCK", pi(ACT_TOGGLE_LOCK, 1)).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_manage),
                "PANEL", pi(ACT_PANEL, 3)).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "STOP", pi(ACT_STOP, 2)).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NID, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
