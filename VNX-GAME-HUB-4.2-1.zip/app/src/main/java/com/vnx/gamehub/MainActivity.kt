package com.vnx.gamehub

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var console: TextView
    private lateinit var timerChip: TextView
    private val refreshers = ArrayList<() -> Unit>()
    private var typer: Runnable? = null
    private var countdown: CountDownTimer? = null
    private var timerLabel = ""
    private var cardIndex = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        root.addView(AnimeBackgroundView(this), FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        buildHeader(col)
        buildConsole(col)
        buildCirclePanel(col)
        buildTools(col)
        buildPermissions(col)
        refreshAll()

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        say("KEOX FF 4.2 ready.\nEvery function is ONE slide switch: slide = ON, slide back = OFF.\n" +
            "In game: swipe the pink edge tab to open the slide panel.")
    }

    override fun onResume() { super.onResume(); refreshAll() }

    // ---------- sections ----------

    private fun buildHeader(col: LinearLayout) {
        val title = ShimmerText(this).apply {
            text = "KEOX FF"; textSize = 32f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.08f; setTextColor(Color.WHITE)
        }
        val sub = TextView(this).apply {
            text = "ANIME EDITION  -  v4.2"; textSize = 11f; letterSpacing = 0.3f
            setTextColor(Theme.PINK); setPadding(dp(2), dp(2), 0, dp(10))
        }
        timerChip = TextView(this).apply {
            text = "TIMER: IDLE"; textSize = 11f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6)); letterSpacing = 0.1f
            background = GradientDrawable().apply {
                cornerRadius = dpf(20f); setColor(Color.parseColor("#33FFFFFF"))
                setStroke(dp(1), Theme.CYAN)
            }
        }
        col.addView(title); col.addView(sub)
        col.addView(timerChip, LinearLayout.LayoutParams(-2, -2))
        enter(title, 0); enter(timerChip, 2)
    }

    private fun buildConsole(col: LinearLayout) {
        console = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(Theme.GREEN)
            minLines = 6; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dpf(16f); setColor(Color.parseColor("#CC050310"))
                setStroke(dp(1), Color.parseColor("#5522D3EE"))
            }
        }
        col.addView(sectionLabel(this, "CONSOLE"))
        col.addView(console, LinearLayout.LayoutParams(-1, -2))
        enter(console, 3)
    }

    private fun buildCirclePanel(col: LinearLayout) {
        col.addView(sectionLabel(this, "CIRCLE  +  LOCK  +  PANEL"))
        slideRow(col, "CIRCLE", "floating circle on screen", Theme.PINK, true,
            { Prefs.getBool(this, "circle_on", false) }) { toggleCircle(); "CIRCLE " + if (Prefs.getBool(this, "circle_on", false)) "ON" else "OFF" }
        slideRow(col, "LOCK", "separate lock button: circle stays + touch passes through", Theme.GOLD, true,
            { Prefs.getBool(this, "locked", false) }) { toggleLock(); if (Prefs.getBool(this, "locked", false)) "CIRCLE LOCKED" else "CIRCLE UNLOCKED" }
        slideRow(col, "PANEL SIDE", "ON = right edge, OFF = left edge", Theme.CYAN, true,
            { Prefs.getBool(this, "panel_right", true) }) {
            Prefs.putBool(this, "panel_right", !Prefs.getBool(this, "panel_right", true)); pushUpdate()
            if (Prefs.getBool(this, "panel_right", true)) "PANEL: RIGHT" else "PANEL: LEFT" }
        col.addView(seek("SIZE", 40, 120, Prefs.getInt(this, "size_dp", 64), "size_dp"))
        col.addView(seek("OPACITY", 20, 100, Prefs.getInt(this, "alpha_pct", 75), "alpha_pct"))
        col.addView(TextView(this).apply {
            text = "In game: swipe the pink edge tab inward to slide the panel in. The padlock is a " +
                "separate button: drag it anywhere, tap it to lock or unlock the circle."
            textSize = 11f; setTextColor(Color.parseColor("#A99CC8")); setPadding(dp(4), dp(8), dp(4), 0)
        })
    }

    private fun buildTools(col: LinearLayout) {
        col.addView(sectionLabel(this, "TOOLS  (slide = ON, slide back = OFF)"))
        slideRow(col, "GAME MODE", "DND + max brightness + rotation lock", Theme.GREEN, false,
            { Prefs.getBool(this, "game_on", false) }) { Tools.gameToggle(this) }
        slideRow(col, "BOOSTER", "animation speed 0.5x", Theme.GOLD, false,
            { Prefs.getBool(this, "boost_on", false) }) { Tools.boostToggle(this) }
        slideRow(col, "SHOW TOUCHES", "touch points on screen", Theme.PINK, false,
            { Prefs.getBool(this, "touches_on", false) }) { Tools.touchesToggle(this) }
        slideRow(col, "SESSION LOG", "start / end play time", Theme.CYAN, false,
            { Prefs.getLong(this, "sess_start", 0L) > 0L }) { Tools.sessionToggle(this) }
        slideRow(col, "TRAINING TIMER", "5 minutes", Theme.PURPLE, true,
            { countdown != null && timerLabel == "TRAINING" }) {
            if (countdown != null && timerLabel == "TRAINING") { stopTimer(); "Timer stopped" }
            else { startTimer(5, "TRAINING"); "TRAINING timer started: 5 min" } }
        slideRow(col, "BREAK TIMER", "10 minutes", Theme.GREEN, true,
            { countdown != null && timerLabel == "BREAK" }) {
            if (countdown != null && timerLabel == "BREAK") { stopTimer(); "Timer stopped" }
            else { startTimer(10, "BREAK"); "BREAK timer started: 10 min" } }

        col.addView(sectionLabel(this, "QUICK INFO"))
        val sys = actionCard("✚", "SYSTEM CHECK", "RAM, battery, ping", Theme.CYAN) { bg { Tools.system(this) } }
        val net = actionCard("≋", "NETWORK", "3 server ping test", Theme.PURPLE) { bg { Tools.network() } }
        val stats = actionCard("Σ", "SESSION STATS", "time played", Theme.GREEN) { say(Tools.sessionStats(this)) }
        val sensi = actionCard("★", "SENSI", "view my presets", Theme.PINK) { say(Tools.sensi(this)) }
        val edit = actionCard("✎", "EDIT SENSI", "change preset values", Theme.GOLD) { editSensi() }
        val open = actionCard("»", "OPEN PANEL", "slide panel now", Theme.CYAN) {
            if (Prefs.getBool(this, "circle_on", false))
                startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_PANEL))
            else Toast.makeText(this, "Turn the CIRCLE on first", Toast.LENGTH_SHORT).show()
        }
        col.addView(row(sys.root, net.root)); col.addView(row(stats.root, sensi.root)); col.addView(row(edit.root, open.root))
    }

    private fun buildPermissions(col: LinearLayout) {
        col.addView(sectionLabel(this, "PERMISSIONS"))
        val a = actionCard("◎", "OVERLAY", "draw over apps", Theme.PINK) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        val b2 = actionCard("⚙", "SETTINGS", "modify system settings", Theme.GOLD) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        val c = actionCard("☾", "DND ACCESS", "do not disturb", Theme.CYAN) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        val d = actionCard("▮", "BATTERY", "set unrestricted", Theme.GREEN) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        col.addView(row(a.root, b2.root)); col.addView(row(c.root, d.root))
        col.addView(TextView(this).apply {
            text = "Circle disappears in game? Do all of these:\n" +
                "1. BATTERY card: allow, and in phone Settings set Keox Ff to Unrestricted.\n" +
                "2. Turn AUTOSTART on for this app (Xiaomi / Oppo / Vivo / Realme).\n" +
                "3. Allow 'Display pop-up windows while running in background' (Xiaomi) or " +
                "'Floating windows' in the app's permissions.\n" +
                "4. Lock the app in Recent Apps (pull the app card down / tap the lock icon).\n" +
                "5. If the phone has a Game Space / Game Turbo, add Keox Ff there too.\n\n" +
                "Boost and Touches need a one-time ADB grant:\n" +
                "adb shell pm grant com.vnx.gamehub android.permission.WRITE_SECURE_SETTINGS"
            textSize = 10f; typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
            setTextColor(Color.parseColor("#A99CC8")); setPadding(dp(4), dp(12), dp(4), 0)
        })
    }

    // ---------- card helpers ----------

    private fun actionCard(glyph: String, title: String, sub: String, accent: Int, click: () -> Unit): NeonCard {
        val c = neonCard(this, glyph, title, sub, accent)
        c.root.setOnClickListener { click() }
        return c
    }

    /** One function = one slide switch. Slide on = ON, slide back = OFF. */
    private fun slideRow(col: LinearLayout, title: String, sub: String, accent: Int, main: Boolean,
                         state: () -> Boolean, action: () -> String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = cardBg(this@MainActivity, accent, false)
        }
        val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        txt.addView(TextView(this).apply {
            text = title; textSize = 14f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); letterSpacing = 0.05f })
        txt.addView(TextView(this).apply { text = sub; textSize = 11f; setTextColor(Color.parseColor("#A99CC8")) })
        val tg = SlideToggle(this, accent)
        tg.setChecked(state(), false)
        tg.onChange = { _ ->
            if (main) {
                say(try { action() } catch (e: Exception) { "[X] ${e.message}" })
                refreshAll()
            } else {
                say("working...")
                Thread {
                    val r = try { action() } catch (e: Exception) { "[X] ${e.message}" }
                    ui.post { say(r); refreshAll() }
                }.start()
            }
        }
        refreshers.add { tg.setChecked(state(), true); box.background = cardBg(this, accent, state()) }
        box.addView(txt, LinearLayout.LayoutParams(0, -2, 1f)); box.addView(tg)
        col.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        enter(box, cardIndex++)
    }

    private fun refreshAll() { refreshers.forEach { it() } }

    private fun row(a: View, b2: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        val params = { left: Boolean ->
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (left) setMargins(0, dp(5), dp(5), dp(5)) else setMargins(dp(5), dp(5), 0, dp(5))
            }
        }
        addView(a, params(true)); addView(b2, params(false))
        enter(a, cardIndex++); enter(b2, cardIndex++)
    }

    private fun seek(label: String, min: Int, max: Int, cur: Int, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(10), dp(4), 0) }
        val tv = TextView(this).apply { text = "$label: $cur"; textSize = 11f; setTextColor(Color.WHITE) }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            progressTintList = ColorStateList.valueOf(Theme.PINK)
            thumbTintList = ColorStateList.valueOf(Theme.CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = "$label: ${p + min}"
                    if (fromUser) { Prefs.putInt(this@MainActivity, key, p + min); pushUpdate() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(tv); box.addView(sb)
        return box
    }

    private fun bg(job: () -> String) {
        say("working...")
        Thread {
            val r = try { job() } catch (e: Exception) { "[X] ${e.message}" }
            ui.post { say(r); refreshAll() }
        }.start()
    }

    private fun say(text: String) {
        typer?.let { ui.removeCallbacks(it) }
        val full = "> $text"
        console.text = ""
        var n = 0
        val r = object : Runnable {
            override fun run() {
                n = minOf(full.length, n + 3)
                console.text = full.substring(0, n)
                if (n < full.length) ui.postDelayed(this, 12)
            }
        }
        typer = r
        ui.post(r)
    }

    // ---------- circle ----------

    private fun toggleCircle() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Draw over other apps' first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Prefs.getBool(this, "circle_on", false)) {
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_STOP))
            Prefs.putBool(this, "circle_on", false)
        } else {
            startForegroundService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_START))
            Prefs.putBool(this, "circle_on", true)
        }
    }

    private fun toggleLock() {
        Prefs.putBool(this, "locked", !Prefs.getBool(this, "locked", false))
        pushUpdate()
        getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun pushUpdate() {
        if (Prefs.getBool(this, "circle_on", false))
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_UPDATE))
    }

    // ---------- timer / sensi ----------

    private fun startTimer(min: Int, label: String) {
        countdown?.cancel()
        timerLabel = label
        countdown = object : CountDownTimer(min * 60_000L, 1000L) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                timerChip.text = "$label  %02d:%02d".format(s / 60, s % 60)
            }
            override fun onFinish() {
                countdown = null
                timerChip.text = "TIMER: DONE"
                say("$label finished.")
                getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                refreshAll()
            }
        }.start()
    }

    private fun stopTimer() {
        countdown?.cancel(); countdown = null
        timerChip.text = "TIMER: IDLE"
        say("Timer stopped.")
    }

    private fun editSensi() {
        val et = EditText(this).apply {
            setText(Prefs.getStr(this@MainActivity, "sensi", Prefs.DEFAULT_SENSI))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            gravity = Gravity.TOP; minLines = 8; typeface = Typeface.MONOSPACE
        }
        AlertDialog.Builder(this)
            .setTitle("Sensi presets (Name=Value per line)")
            .setView(et)
            .setPositiveButton("SAVE") { _, _ ->
                Prefs.putStr(this, "sensi", et.text.toString()); say(Tools.sensi(this))
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    override fun onDestroy() {
        countdown?.cancel()
        typer?.let { ui.removeCallbacks(it) }
        super.onDestroy()
    }
}
