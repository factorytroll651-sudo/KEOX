package com.vnx.gamehub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gaming-only coach. Needs an Anthropic API key saved in SETTINGS; falls back to offline tips. */
object AiBot {
    private const val SYSTEM =
        "You are Keox AI, a Free Fire and mobile-gaming coach inside the Keox Ff app. " +
            "Answer ONLY questions about Free Fire and mobile gaming: weapons, headshot technique, sensitivity, " +
            "HUD layout, characters, pets, maps, ranked and squad strategy, and phone performance for gaming. " +
            "If the user asks about anything else, reply in one short line that you only answer gaming questions. " +
            "Never help with cheats, hacks, aimbots, mods, injectors, recoil scripts or ban evasion; say they get " +
            "accounts banned and suggest legitimate practice instead. " +
            "Reply in the same language the user writes in (Hindi, Hinglish or English), in short clear steps."

    fun reply(c: Context, history: List<Pair<String, String>>): String {
        val key = Prefs.getStr(c, "ai_key", "").trim()
        val last = history.lastOrNull { it.first == "user" }?.second ?: ""
        if (key.isEmpty()) return Coach.offline(last)
        return try {
            val msgs = JSONArray()
            for ((role, text) in history.takeLast(12)) msgs.put(JSONObject().put("role", role).put("content", text))
            val body = JSONObject()
                .put("model", Prefs.getStr(c, "ai_model", "claude-haiku-5-5"))
                .put("max_tokens", 700)
                .put("system", SYSTEM)
                .put("messages", msgs)
            val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(200) }
                return "AI error $code: $msg"
            }
            val arr = JSONObject(txt).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("type") == "text") sb.append(o.optString("text"))
            }
            if (sb.isEmpty()) "(no answer)" else sb.toString().trim()
        } catch (e: Exception) {
            "Could not reach the AI (${e.javaClass.simpleName}). Check internet and your key in SETTINGS.\n\n" + Coach.offline(last)
        }
    }
}
