package com.vnx.gamehub

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var console: TextView
    private lateinit var timerChip: TextView
    private lateinit var content: FrameLayout
    private lateinit var gRam: GaugeView
    private lateinit var gBat: GaugeView
    private lateinit var heroInfo: TextView
    private lateinit var aiList: LinearLayout
    private lateinit var aiScroll: ScrollView
    private lateinit var aiInput: EditText
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()
    private val refreshers = ArrayList<() -> Unit>()
    private val chat = ArrayList<Pair<String, String>>()
    private var typer: Runnable? = null
    private var countdown: CountDownTimer? = null
    private var timerLabel = ""
    private var cardIndex = 0
    private val dev by lazy { Device.read(this) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        root.addView(AnimeBackgroundView(this), FrameLayout.LayoutParams(-1, -1))

        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        main.addView(buildHeader(), LinearLayout.LayoutParams(-1, -2))
        console = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Theme.GREEN)
            minLines = 2; maxLines = 4; setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dpf(14f); setColor(Color.parseColor("#CC050310"))
                setStroke(dp(1), Color.parseColor("#5522D3EE"))
            }
        }
        main.addView(console, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(6), dp(14), dp(4)) })
        content = FrameLayout(this)
        main.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(buildNav(), LinearLayout.LayoutParams(-1, -2))
        root.addView(main, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        pages.add(homePage()); pages.add(toolsPage()); pages.add(sensiPage()); pages.add(aiPage()); pages.add(settingsPage())
        for (p in pages) content.addView(p, FrameLayout.LayoutParams(-1, -1))
        showPage(intent.getIntExtra("page", 0))
        refreshAll()

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        say("KEOX FF 5.0 ready on ${dev.brand} ${dev.model}.\nTap a tile: lit = ON, tap again = OFF.")
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        if (i != null) { intent = i; showPage(i.getIntExtra("page", 0)) }
    }

    override fun onResume() { super.onResume(); refreshAll() }

    // ---------- frame ----------

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(2))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ShimmerText(this).apply {
            text = "KEOX FF"; textSize = 26f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.1f; setTextColor(Color.WHITE)
        })
        col.addView(TextView(this).apply {
            text = "GAME HUB  -  v5.0"; textSize = 10f; letterSpacing = 0.3f; setTextColor(Theme.PINK)
        })
        timerChip = TextView(this).apply {
            text = "TIMER: IDLE"; textSize = 10f; setTextColor(Color.WHITE)
            setPadding(dp(10), dp(5), dp(10), dp(5)); letterSpacing = 0.1f
            background = GradientDrawable().apply {
                cornerRadius = dpf(20f); setColor(Color.parseColor("#33FFFFFF")); setStroke(dp(1), Theme.CYAN)
            }
        }
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(timerChip)
        return row
    }

    private fun buildNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(dpf(22f), dpf(22f), dpf(22f), dpf(22f), 0f, 0f, 0f, 0f)
                setColor(Color.parseColor("#F0121218")); setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
        }
        val items = listOf("⌂" to "HOME", "▦" to "TOOLS", "◎" to "SENSI", "✦" to "AI", "⚙" to "SETTINGS")
        items.forEachIndexed { i, it2 ->
            val tv = TextView(this).apply {
                text = "${it2.first}\n${it2.second}"; gravity = Gravity.CENTER; textSize = 10f
                setTextColor(Color.parseColor("#8A8A98")); setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { showPage(i) }
            }
            navItems.add(tv)
            bar.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return bar
    }

    private fun showPage(i: Int) {
        val k = i.coerceIn(0, pages.size - 1)
        pages.forEachIndexed { n, p -> p.visibility = if (n == k) View.VISIBLE else View.GONE }
        navItems.forEachIndexed { n, t -> t.setTextColor(if (n == k) Theme.PINK else Color.parseColor("#8A8A98")) }
        pages[k].alpha = 0f
        pages[k].animate().alpha(1f).setDuration(220).start()
    }

    private fun pageScroll(build: (LinearLayout) -> Unit): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(24))
        }
        build(col)
        return ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) }
    }

    // ---------- pages ----------

    private fun homePage(): View = pageScroll { col ->
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = cardBg(this@MainActivity, Theme.PURPLE, false)
        }
        hero.addView(TextView(this).apply {
            text = "${dev.brand} ${dev.model}"; textSize = 17f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        })
        heroInfo = TextView(this).apply {
            text = "${dev.tierName}  |  ${dev.hz.toInt()} Hz  |  ${dev.ramMb} MB  |  ${dev.soc}"
            textSize = 11f; setTextColor(Color.parseColor("#A99CC8")); setPadding(0, dp(2), 0, dp(10))
        }
        hero.addView(heroInfo)
        gRam = GaugeView(this, Theme.CYAN); gBat = GaugeView(this, Theme.GREEN)
        val g = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        g.addView(gRam, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(14), 0, dp(14), 0) })
        g.addView(gBat, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(14), 0, dp(14), 0) })
        hero.addView(g)
        col.addView(hero)
        enter(hero, cardIndex++)

        col.addView(sectionLabel(this, "PERFORMANCE MODE"))
        val mode = Segmented(this, listOf("BATTERY SAVER", "BALANCED", "BOOST"), Color.parseColor("#6EC1FF"))
        mode.select(Prefs.getInt(this, "perf_mode", 1), false)
        mode.onSelect = { i -> bg { Tools.setMode(this, i) } }
        col.addView(mode)

        col.addView(sectionLabel(this, "CIRCLE + SLIDE PANEL"))
        grid(col, listOf(
            toolTile("◎", "CIRCLE", Theme.PINK, true, { Prefs.getBool(this, "circle_on", false) }) {
                toggleCircle(); "CIRCLE " + if (Prefs.getBool(this, "circle_on", false)) "ON" else "OFF" },
            toolTile("⚿", "LOCK", Theme.GOLD, true, { Prefs.getBool(this, "locked", false) }) {
                toggleLock(); if (Prefs.getBool(this, "locked", false)) "CIRCLE LOCKED" else "CIRCLE UNLOCKED" },
            toolTile("⇆", "PANEL RIGHT", Theme.CYAN, true, { Prefs.getBool(this, "panel_right", true) }) {
                Prefs.putBool(this, "panel_right", !Prefs.getBool(this, "panel_right", true)); pushUpdate()
                if (Prefs.getBool(this, "panel_right", true)) "PANEL: RIGHT" else "PANEL: LEFT" },
            toolTile("»", "OPEN PANEL", Theme.GREEN, true, null) {
                if (Prefs.getBool(this, "circle_on", false)) {
                    startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_PANEL))
                    "Panel opened"
                } else "Turn the CIRCLE on first" },
            toolTile("▶", "AUTO FREE FIRE", Theme.GOLD, true, { Prefs.getBool(this, "auto_ff", true) }) {
                Prefs.putBool(this, "auto_ff", !Prefs.getBool(this, "auto_ff", true))
                if (!Tools.hasUsageAccess(this)) "AUTO FF set. Now allow USAGE ACCESS in SETTINGS."
                else "AUTO FREE FIRE " + if (Prefs.getBool(this, "auto_ff", true)) "ON" else "OFF" },
            toolTile("◐", "FF ONLY", Theme.PURPLE, true, { Prefs.getBool(this, "ff_only", false) }) {
                Prefs.putBool(this, "ff_only", !Prefs.getBool(this, "ff_only", false)); pushUpdate()
                if (Prefs.getBool(this, "ff_only", false)) "Circle shows only in Free Fire" else "Circle shows everywhere" }
        ))
        col.addView(seek("SIZE", 40, 120, Prefs.getInt(this, "size_dp", 64), "size_dp"))
        col.addView(seek("OPACITY", 20, 100, Prefs.getInt(this, "alpha_pct", 75), "alpha_pct"))
        col.addView(note("Swipe the pink edge tab inward in game to slide the panel in. " +
            "Lock the circle on your fire button: it stays put and your touch passes through to the game."))
    }

    private fun toolsPage(): View = pageScroll { col ->
        col.addView(sectionLabel(this, "GAME TOOLS  (tap = ON, tap again = OFF)"))
        val b = { k: String -> Prefs.getBool(this, k, false) }
        grid(col, listOf(
            toolTile("⚔", "ESPORTS MODE", Theme.GOLD, false, { b("esports_on") }) { Tools.esportsToggle(this) },
            toolTile("⊘", "BLOCK NOTIFS", Theme.PINK, false, { b("dnd_on") }) { Tools.dndToggle(this) },
            toolTile("☀", "BRIGHT LOCK", Theme.GOLD, false, { b("bright_lock") }) { Tools.brightLockToggle(this) },
            toolTile("☝", "TOUCHES", Theme.CYAN, false, { b("touches_on") }) { Tools.touchesToggle(this) },
            toolTile("⟳", "ROTATION LOCK", Theme.GREEN, false, { b("rot_lock") }) { Tools.rotLockToggle(this) },
            toolTile("♪", "VOLUME MAX", Theme.PURPLE, false, null) { Tools.volumeMax(this) },
            toolTile("⌫", "CLEAN RAM", Theme.CYAN, false, null) { Tools.cleanRam(this) },
            toolTile("⚡", "BOOST MAX", Theme.GOLD, false, { Prefs.getInt(this, "perf_mode", 1) == 2 }) {
                if (Prefs.getInt(this, "perf_mode", 1) == 2) Tools.setMode(this, 1) else Tools.setMode(this, 2) },
            toolTile("▷", "SESSION", Theme.GREEN, false, { Prefs.getLong(this, "sess_start", 0L) > 0L }) { Tools.sessionToggle(this) }
        ))
        col.addView(sectionLabel(this, "TIMERS"))
        grid(col, listOf(
            toolTile("5", "TRAINING 5 MIN", Theme.PURPLE, true, { countdown != null && timerLabel == "TRAINING" }) {
                if (countdown != null && timerLabel == "TRAINING") { stopTimer(); "Timer stopped" }
                else { startTimer(5, "TRAINING"); "TRAINING timer: 5 min" } },
            toolTile("10", "BREAK 10 MIN", Theme.GREEN, true, { countdown != null && timerLabel == "BREAK" }) {
                if (countdown != null && timerLabel == "BREAK") { stopTimer(); "Timer stopped" }
                else { startTimer(10, "BREAK"); "BREAK timer: 10 min" } },
            toolTile("Σ", "SESSION STATS", Theme.CYAN, true, null) { Tools.sessionStats(this) }
        ))
        col.addView(sectionLabel(this, "INFO"))
        grid(col, listOf(
            toolTile("✚", "SYSTEM CHECK", Theme.CYAN, false, null) { Tools.system(this) },
            toolTile("≋", "PING TEST", Theme.PURPLE, false, null) { Tools.network() },
            toolTile("★", "MY SENSI", Theme.PINK, true, null) { Tools.sensi(this) }
        ))
    }

    private fun sensiPage(): View = pageScroll { col ->
        col.addView(sectionLabel(this, "YOUR DEVICE"))
        col.addView(panelText(Device.details(dev), true))

        col.addView(sectionLabel(this, "SENSITIVITY FOR YOUR PHONE"))
        var style = Prefs.getInt(this, "sensi_style", 0)
        val values = panelText(Device.sensiText(Device.sensi(dev, style)), true)
        val seg = Segmented(this, listOf("BALANCED", "FAST FLICK", "PRECISE"), Color.parseColor("#6EC1FF"))
        seg.select(style, false)
        seg.onSelect = { i ->
            style = i; Prefs.putInt(this, "sensi_style", i)
            values.text = Device.sensiText(Device.sensi(dev, i))
        }
        col.addView(seg)
        col.addView(values, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        btns.addView(pill("SAVE AS MY PRESETS", Theme.GREEN) {
            Prefs.putStr(this, "sensi", Device.sensiText(Device.sensi(dev, style))); say("Saved.\n" + Tools.sensi(this))
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        btns.addView(pill("COPY", Theme.CYAN) {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("sensi", Device.sensiText(Device.sensi(dev, style))))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        btns.addView(pill("EDIT", Theme.GOLD) { editSensi() }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        col.addView(btns)
        col.addView(note("These are estimates from your screen size, refresh rate and RAM. " +
            "Enter them in Free Fire > Settings > Sensitivity and fine-tune in the training ground."))

        col.addView(sectionLabel(this, "DPI CALCULATOR"))
        val et = EditText(this).apply {
            hint = "smallest width in dp (now ${dev.swDp})"; inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#8A8A98")); textSize = 13f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { cornerRadius = dpf(14f); setColor(Color.parseColor("#33FFFFFF")) }
        }
        val res = panelText("Type a number between 280 and 600, then tap CALCULATE.", true)
        col.addView(et)
        col.addView(pill("CALCULATE", Theme.PINK) {
            val n = et.text.toString().toIntOrNull() ?: 0
            res.text = Device.dpiCalc(dev, n)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        col.addView(res, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        col.addView(sectionLabel(this, "HUD GUIDE"))
        col.addView(panelText(Device.hud(dev), false))
        col.addView(sectionLabel(this, "OPTIMIZATION"))
        col.addView(panelText(Device.OPT_TIPS, false))
        col.addView(sectionLabel(this, "HEADSHOT TRAINING"))
        col.addView(panelText(Device.TRAIN_TIPS, false))
    }

    private fun aiPage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(6), dp(14), dp(8))
        }
        page.addView(TextView(this).apply {
            text = "AI COACH  -  Free Fire and gaming questions only"
            textSize = 11f; letterSpacing = 0.1f; setTextColor(Theme.CYAN); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(8), 0, dp(8))
        })
        aiList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        aiScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(aiList) }
        page.addView(aiScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addBubble("Hi! Ask me about Free Fire: UMP headshots, sensitivity, HUD, ranks, lag. " +
            "Try: \"UMP se headshot kaise maru?\"\nAdd your AI key in SETTINGS for full answers.", false)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        aiInput = EditText(this).apply {
            hint = "Ask about Free Fire..."; setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#8A8A98"))
            textSize = 13f; maxLines = 3; setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { cornerRadius = dpf(22f); setColor(Color.parseColor("#33FFFFFF")) }
        }
        row.addView(aiInput, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(pill("SEND", Theme.PINK) { sendAi() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        page.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        return page
    }

    private fun settingsPage(): View = pageScroll { col ->
        col.addView(sectionLabel(this, "AI COACH KEY"))
        val key = EditText(this).apply {
            hint = if (Prefs.getStr(this@MainActivity, "ai_key", "").isEmpty()) "paste your Anthropic API key" else "key saved (paste to replace)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#8A8A98")); textSize = 13f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { cornerRadius = dpf(14f); setColor(Color.parseColor("#33FFFFFF")) }
        }
        val model = EditText(this).apply {
            setText(Prefs.getStr(this@MainActivity, "ai_model", "claude-haiku-5-5"))
            setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { cornerRadius = dpf(14f); setColor(Color.parseColor("#33FFFFFF")) }
        }
        col.addView(key)
        col.addView(model, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        col.addView(pill("SAVE AI SETTINGS", Theme.GREEN) {
            val k = key.text.toString().trim()
            if (k.isNotEmpty()) Prefs.putStr(this, "ai_key", k)
            Prefs.putStr(this, "ai_model", model.text.toString().trim().ifEmpty { "claude-haiku-5-5" })
            say("AI settings saved.")
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        col.addView(note("Get a key at console.anthropic.com. It stays on this phone and is sent only to api.anthropic.com. " +
            "Answers use your own API credit. Without a key you still get offline tips."))

        col.addView(sectionLabel(this, "AUTO FREE FIRE"))
        grid(col, listOf(
            toolTile("▶", "AUTO ON", Theme.GOLD, true, { Prefs.getBool(this, "auto_ff", true) }) {
                Prefs.putBool(this, "auto_ff", !Prefs.getBool(this, "auto_ff", true))
                "AUTO FREE FIRE " + if (Prefs.getBool(this, "auto_ff", true)) "ON" else "OFF" },
            toolTile("↺", "AUTO RESTORE", Theme.GREEN, true, { Prefs.getBool(this, "auto_restore", true) }) {
                Prefs.putBool(this, "auto_restore", !Prefs.getBool(this, "auto_restore", true))
                "RESTORE ON EXIT " + if (Prefs.getBool(this, "auto_restore", true)) "ON" else "OFF" },
            toolTile("◐", "FF ONLY", Theme.PURPLE, true, { Prefs.getBool(this, "ff_only", false) }) {
                Prefs.putBool(this, "ff_only", !Prefs.getBool(this, "ff_only", false)); pushUpdate()
                "FF ONLY " + if (Prefs.getBool(this, "ff_only", false)) "ON" else "OFF" }
        ))
        col.addView(note("Keep the CIRCLE on. When Free Fire opens, Keox Ff turns Esports mode on by itself, " +
            "and turns it off when you leave. It needs USAGE ACCESS below."))

        col.addView(sectionLabel(this, "PERMISSIONS"))
        grid(col, listOf(
            toolTile("◎", "OVERLAY", Theme.PINK, true, null) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); "Allow draw over apps" },
            toolTile("⚙", "SETTINGS", Theme.GOLD, true, null) {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))); "Allow modify settings" },
            toolTile("☾", "DND ACCESS", Theme.CYAN, true, null) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); "Allow Do Not Disturb" },
            toolTile("◔", "USAGE ACCESS", Theme.GREEN, true, { Tools.hasUsageAccess(this) }) {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); "Allow usage access for Keox Ff" },
            toolTile("▮", "BATTERY", Theme.PURPLE, true, null) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                "Set to unrestricted" }
        ))
        col.addView(note("Circle disappears in game? Do all of these:\n" +
            "1. BATTERY: allow, and in phone Settings set Keox Ff to Unrestricted.\n" +
            "2. Turn AUTOSTART on for this app (Xiaomi / Oppo / Vivo / Realme).\n" +
            "3. Allow 'Display pop-up windows while running in background' or 'Floating windows'.\n" +
            "4. Lock the app in Recent Apps.\n" +
            "5. If your phone has Game Space / Game Turbo, add Keox Ff there too."))
        col.addView(note("Booster and Touches need a one-time ADB grant:\n" +
            "adb shell pm grant com.vnx.gamehub android.permission.WRITE_SECURE_SETTINGS"))
    }

    // ---------- widgets ----------

    private fun toolTile(glyph: String, label: String, accent: Int, main: Boolean,
                         state: (() -> Boolean)?, action: () -> String): Tile {
        val t = tile(this, glyph, label, accent)
        if (state != null) refreshers.add { t.setOn(state()) }
        t.root.setOnClickListener {
            if (main) {
                say(try { action() } catch (e: Exception) { "[X] ${e.message}" })
                refreshAll()
            } else bg(action)
        }
        return t
    }

    private fun grid(col: LinearLayout, tiles: List<Tile>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dpf(22f); setColor(Color.parseColor("#CC15151C"))
                setStroke(dp(1), Color.parseColor("#22FFFFFF"))
            }
        }
        var i = 0
        while (i < tiles.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until 3) {
                val v: View = if (i + k < tiles.size) tiles[i + k].root else View(this@MainActivity)
                row.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            card.addView(row)
            i += 3
        }
        col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        enter(card, cardIndex++)
    }

    private fun pill(text: String, accent: Int, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f
        setPadding(dp(12), dp(11), dp(12), dp(11))
        background = GradientDrawable().apply {
            cornerRadius = dpf(22f); setColor(Color.parseColor("#26FFFFFF")); setStroke(dp(1), accent)
        }
        setOnClickListener { click() }
    }

    private fun note(text: String): TextView = TextView(this).apply {
        this.text = text; textSize = 11f; setTextColor(Color.parseColor("#A99CC8")); setPadding(dp(4), dp(10), dp(4), 0)
    }

    private fun panelText(text: String, mono: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = if (mono) 12f else 12f; setTextColor(Color.parseColor("#E8E8F0"))
        if (mono) typeface = Typeface.MONOSPACE
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dpf(16f); setColor(Color.parseColor("#CC15151C")); setStroke(dp(1), Color.parseColor("#22FFFFFF"))
        }
    }

    private fun seek(label: String, min: Int, max: Int, cur: Int, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(10), dp(4), 0) }
        val tv = TextView(this).apply { text = "$label: $cur"; textSize = 11f; setTextColor(Color.WHITE) }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            progressTintList = ColorStateList.valueOf(Theme.PINK)
            thumbTintList = ColorStateList.valueOf(Theme.CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = "$label: ${p + min}"
                    if (fromUser) { Prefs.putInt(this@MainActivity, key, p + min); pushUpdate() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(tv); box.addView(sb)
        return box
    }

    // ---------- helpers ----------

    private fun refreshAll() {
        refreshers.forEach { it() }
        if (this::gRam.isInitialized) {
            gRam.set(Tools.ramUsedPct(this), "RAM")
            gBat.set(Tools.batteryPct(this), "BATTERY")
        }
    }

    private fun bg(job: () -> String) {
        say("working...")
        Thread {
            val r = try { job() } catch (e: Exception) { "[X] ${e.message}" }
            ui.post { say(r); refreshAll() }
        }.start()
    }

    private fun say(text: String) {
        typer?.let { ui.removeCallbacks(it) }
        val full = "> $text"
        console.text = ""
        var n = 0
        val r = object : Runnable {
            override fun run() {
                n = minOf(full.length, n + 4)
                console.text = full.substring(0, n)
                if (n < full.length) ui.postDelayed(this, 10)
            }
        }
        typer = r
        ui.post(r)
    }

    // ---------- AI chat ----------

    private fun addBubble(text: String, user: Boolean): TextView {
        val tv = TextView(this).apply {
            this.text = text; textSize = 13f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
            background = GradientDrawable().apply {
                cornerRadius = dpf(18f)
                setColor(if (user) Color.parseColor("#CCB83A74") else Color.parseColor("#CC24242E"))
            }
            setTextIsSelectable(true)
        }
        aiList.addView(tv, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = if (user) Gravity.END else Gravity.START; topMargin = dp(8)
        })
        aiScroll.post { aiScroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun sendAi() {
        val q = aiInput.text.toString().trim()
        if (q.isEmpty()) return
        aiInput.setText("")
        addBubble(q, true)
        chat.add("user" to q)
        val typing = addBubble("...", false)
        val snapshot = ArrayList(chat)
        Thread {
            val r = AiBot.reply(this, snapshot)
            ui.post {
                typing.text = r
                chat.add("assistant" to r)
                aiScroll.post { aiScroll.fullScroll(View.FOCUS_DOWN) }
            }
        }.start()
    }

    // ---------- circle ----------

    private fun toggleCircle() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Draw over other apps' first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Prefs.getBool(this, "circle_on", false)) {
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_STOP))
            Prefs.putBool(this, "circle_on", false)
        } else {
            startForegroundService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_START))
            Prefs.putBool(this, "circle_on", true)
        }
    }

    private fun toggleLock() {
        Prefs.putBool(this, "locked", !Prefs.getBool(this, "locked", false))
        pushUpdate()
        getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun pushUpdate() {
        if (Prefs.getBool(this, "circle_on", false))
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACT_UPDATE))
    }

    // ---------- timer / sensi ----------

    private fun startTimer(min: Int, label: String) {
        countdown?.cancel()
        timerLabel = label
        countdown = object : CountDownTimer(min * 60_000L, 1000L) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                timerChip.text = "$label  %02d:%02d".format(s / 60, s % 60)
            }
            override fun onFinish() {
                countdown = null
                timerChip.text = "TIMER: DONE"
                say("$label finished.")
                getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                refreshAll()
            }
        }.start()
    }

    private fun stopTimer() {
        countdown?.cancel(); countdown = null
        timerChip.text = "TIMER: IDLE"
    }

    private fun editSensi() {
        val et = EditText(this).apply {
            setText(Prefs.getStr(this@MainActivity, "sensi", Prefs.DEFAULT_SENSI))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            gravity = Gravity.TOP; minLines = 8; typeface = Typeface.MONOSPACE
        }
        AlertDialog.Builder(this)
            .setTitle("Sensi presets (Name=Value per line)")
            .setView(et)
            .setPositiveButton("SAVE") { _, _ ->
                Prefs.putStr(this, "sensi", et.text.toString()); say(Tools.sensi(this))
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    override fun onDestroy() {
        countdown?.cancel()
        typer?.let { ui.removeCallbacks(it) }
        super.onDestroy()
    }
}
