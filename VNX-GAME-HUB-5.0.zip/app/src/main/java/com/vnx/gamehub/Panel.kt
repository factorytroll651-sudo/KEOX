package com.vnx.gamehub

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * In-game slide-out panel (tabs on the left, tiles on the right).
 * Tap a tile: it lights up when ON; tap again for OFF. Tap the dark area outside to go back to the game.
 */
class SidePanel(
    ctx: Context,
    private val right: Boolean,
    private val onClose: () -> Unit,
    private val onLock: () -> Unit
) : FrameLayout(ctx) {

    private class T(val glyph: String, val label: String, val accent: Int, val main: Boolean,
                    val state: (() -> Boolean)?, val action: () -> String)

    private val ui = Handler(Looper.getMainLooper())
    private val status = TextView(ctx)
    private val box = LinearLayout(ctx)
    private val pages = ArrayList<View>()
    private val railItems = ArrayList<TextView>()
    private val refreshers = ArrayList<() -> Unit>()
    private var closing = false
    private val panelW = minOf(ctx.dp(500), (ctx.resources.displayMetrics.widthPixels * 0.92f).toInt())
    private val gRam = GaugeView(ctx, Theme.CYAN)
    private val gBat = GaugeView(ctx, Theme.GREEN)
    private val info = TextView(ctx)
    private val sensiTv = TextView(ctx)
    private var style = Prefs.getInt(ctx, "sensi_style", 0)

    init {
        setBackgroundColor(Color.argb(110, 0, 0, 0))
        alpha = 0f
        setOnClickListener { close() }

        box.orientation = LinearLayout.HORIZONTAL
        box.isClickable = true
        box.background = GradientDrawable().apply {
            cornerRadius = ctx.dpf(26f); setColor(Color.parseColor("#F2191920"))
            setStroke(ctx.dp(1), Color.parseColor("#33FFFFFF"))
        }

        val rail = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ctx.dp(4), ctx.dp(14), ctx.dp(4), ctx.dp(8))
            background = GradientDrawable().apply { cornerRadius = ctx.dpf(26f); setColor(Color.parseColor("#26262E")) }
        }
        railTab(rail, "⚡", "Performance", 0)
        railTab(rail, "▦", "Game tools", 1)
        railTab(rail, "◎", "Sensi", 2)
        railTab(rail, "✦", "AI coach", -1)
        box.addView(rail, LinearLayout.LayoutParams(ctx.dp(78), ViewGroup.LayoutParams.MATCH_PARENT))

        val content = FrameLayout(ctx)
        pages.add(scroll(perfPage())); pages.add(scroll(toolsPage())); pages.add(scroll(sensiPage()))
        for (p in pages) content.addView(p, LayoutParams(-1, -1))

        val rightCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        rightCol.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        status.apply {
            typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Theme.GREEN); maxLines = 4
            setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8)); text = "> ready"
            background = GradientDrawable().apply { cornerRadius = ctx.dpf(12f); setColor(Color.parseColor("#CC050310")) }
        }
        rightCol.addView(status, LinearLayout.LayoutParams(-1, -2).apply { setMargins(ctx.dp(10), 0, ctx.dp(10), ctx.dp(10)) })
        box.addView(rightCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        val lp = LayoutParams(panelW, ViewGroup.LayoutParams.MATCH_PARENT, if (right) Gravity.END else Gravity.START)
        lp.setMargins(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        addView(box, lp)
        showTab(0)
        syncAll()
    }

    // ---------- structure ----------

    private fun scroll(v: View): View = ScrollView(context).apply {
        isVerticalScrollBarEnabled = false; addView(v)
    }

    private fun railTab(rail: LinearLayout, glyph: String, label: String, idx: Int) {
        val c = context
        val tv = TextView(c).apply {
            text = "$glyph\n$label"; gravity = Gravity.CENTER; textSize = 11f
            setTextColor(Color.parseColor("#B8B8C4")); setPadding(0, c.dp(12), 0, c.dp(12))
            setOnClickListener { if (idx >= 0) showTab(idx) else openApp(3) }
        }
        railItems.add(tv)
        rail.addView(tv, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showTab(i: Int) {
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        railItems.forEachIndexed { k, t ->
            t.setTextColor(if (k == i) Theme.GOLD else Color.parseColor("#B8B8C4"))
        }
        if (i == 0) syncAll()
    }

    private fun label(text: String): TextView = TextView(context).apply {
        this.text = text; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        setPadding(context.dp(2), context.dp(14), 0, context.dp(8))
    }

    private fun column(): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(context.dp(14), context.dp(10), context.dp(14), context.dp(10))
    }

    // ---------- pages ----------

    private fun perfPage(): View {
        val c = context
        val col = column()
        val gauges = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val lpG = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { gravity = Gravity.CENTER } }
        gauges.addView(gRam, lpG()); gauges.addView(gBat, lpG())
        col.addView(gauges)
        info.apply { textSize = 12f; setTextColor(Color.parseColor("#B8B8C4")); gravity = Gravity.CENTER; setPadding(0, c.dp(8), 0, c.dp(8)) }
        col.addView(info)

        val mode = Segmented(c, listOf("BATTERY SAVER", "BALANCED", "BOOST"), Color.parseColor("#6EC1FF"))
        mode.select(Prefs.getInt(c, "perf_mode", 1), false)
        mode.onSelect = { i -> run { Tools.setMode(c, i) } }
        col.addView(mode)

        col.addView(label("Refresh rate"))
        val hzList = Tools.refreshList(c)
        val seg = Segmented(c, listOf("AUTO") + hzList.map { "$it Hz" }, Color.parseColor("#6EC1FF"))
        val cur = Prefs.getInt(c, "refresh_hz", 0)
        seg.select(if (cur <= 0) 0 else (hzList.indexOf(cur) + 1).coerceAtLeast(0), false)
        seg.onSelect = { i -> run { Tools.setRefresh(c, if (i == 0) 0 else hzList[i - 1]) } }
        col.addView(seg)

        col.addView(label("Network"))
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val wifi = tile(c, "⌁", "Wi-Fi", Theme.CYAN)
        val data = tile(c, "⇅", "Mobile data", Theme.GOLD)
        wifi.root.setOnClickListener { openSettingsPanel(true) }
        data.root.setOnClickListener { openSettingsPanel(false) }
        row.addView(wifi.root, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(data.root, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(row)
        return col
    }

    private fun toolsPage(): View {
        val c = context
        val col = column()
        val b = { k: String -> Prefs.getBool(c, k, false) }
        val list = listOf(
            T("⚔", "ESPORTS MODE", Theme.GOLD, false, { b("esports_on") }) { Tools.esportsToggle(c) },
            T("⊘", "BLOCK NOTIFS", Theme.PINK, false, { b("dnd_on") }) { Tools.dndToggle(c) },
            T("☀", "BRIGHT LOCK", Theme.GOLD, false, { b("bright_lock") }) { Tools.brightLockToggle(c) },
            T("☝", "TOUCHES", Theme.CYAN, false, { b("touches_on") }) { Tools.touchesToggle(c) },
            T("⟳", "ROTATION LOCK", Theme.GREEN, false, { b("rot_lock") }) { Tools.rotLockToggle(c) },
            T("♪", "VOLUME MAX", Theme.PURPLE, false, null) { Tools.volumeMax(c) },
            T("⌫", "CLEAN RAM", Theme.CYAN, false, null) { Tools.cleanRam(c) },
            T("⚿", "LOCK CIRCLE", Theme.GOLD, true, { b("locked") }) {
                onLock(); if (b("locked")) "CIRCLE LOCKED" else "CIRCLE UNLOCKED" },
            T("▷", "SESSION", Theme.GREEN, false, { Prefs.getLong(c, "sess_start", 0L) > 0L }) { Tools.sessionToggle(c) },
            T("✚", "SYSTEM", Theme.CYAN, false, null) { Tools.system(c) },
            T("≋", "PING", Theme.PURPLE, false, null) { Tools.network() },
            T("✦", "AI COACH", Theme.PINK, true, null) { openApp(3); "Opening AI coach..." }
        )
        var rowView: LinearLayout? = null
        list.forEachIndexed { i, d ->
            if (i % 3 == 0) {
                rowView = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
                col.addView(rowView)
            }
            val t = tile(c, d.glyph, d.label, d.accent)
            val st = d.state
            if (st != null) refreshers.add { t.setOn(st()) }
            t.root.setOnClickListener { exec(d.main, d.action) }
            rowView?.addView(t.root, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return col
    }

    private fun sensiPage(): View {
        val c = context
        val col = column()
        val d = Device.read(c)
        col.addView(label("${d.brand} ${d.model}"))
        col.addView(TextView(c).apply {
            text = Device.details(d); typeface = Typeface.MONOSPACE; textSize = 10f
            setTextColor(Color.parseColor("#B8B8C4"))
        })
        col.addView(label("Sensitivity (start here)"))
        val seg = Segmented(c, listOf("BALANCED", "FAST", "PRECISE"), Color.parseColor("#6EC1FF"))
        seg.select(style, false)
        sensiTv.apply { typeface = Typeface.MONOSPACE; textSize = 13f; setTextColor(Color.WHITE); setPadding(0, c.dp(10), 0, c.dp(4)) }
        seg.onSelect = { i ->
            style = i; Prefs.putInt(c, "sensi_style", i)
            sensiTv.text = Device.sensiText(Device.sensi(d, i))
        }
        sensiTv.text = Device.sensiText(Device.sensi(d, style))
        col.addView(seg); col.addView(sensiTv)
        col.addView(TextView(c).apply {
            text = "Estimates from your screen, refresh rate and RAM. Tune in the training ground."
            textSize = 10f; setTextColor(Color.parseColor("#8A8A98"))
        })
        return col
    }

    // ---------- actions ----------

    private fun exec(main: Boolean, job: () -> String) {
        if (main) {
            say(try { job() } catch (e: Exception) { "[X] ${e.message}" })
            syncAll()
        } else run(job)
    }

    private fun run(job: () -> String) {
        say("working...")
        Thread {
            val r = try { job() } catch (e: Exception) { "[X] ${e.message}" }
            ui.post { say(r); syncAll() }
        }.start()
    }

    private fun syncAll() {
        refreshers.forEach { it() }
        val c = context
        gRam.set(Tools.ramUsedPct(c), "RAM")
        gBat.set(Tools.batteryPct(c), "BATTERY")
        val m = Tools.gameMinutes(c)
        info.text = "Game time ${m / 60} hr ${m % 60} min   |   Temp ${"%.1f".format(Tools.batteryTemp(c))}C"
    }

    private fun say(t: String) { status.text = "> $t" }

    private fun openApp(page: Int) {
        try {
            context.startActivity(Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("page", page))
        } catch (e: Exception) { say("[X] ${e.message}") }
    }

    private fun openSettingsPanel(wifi: Boolean) {
        try {
            val action = if (Build.VERSION.SDK_INT >= 29)
                (if (wifi) Settings.Panel.ACTION_WIFI else Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
            else Settings.ACTION_WIRELESS_SETTINGS
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { say("[X] ${e.message}") }
    }

    // ---------- open / close ----------

    fun open() {
        box.translationX = if (right) panelW.toFloat() else -panelW.toFloat()
        box.animate().translationX(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        animate().alpha(1f).setDuration(200).start()
    }

    fun close() {
        if (closing) return
        closing = true
        box.animate().translationX(if (right) panelW.toFloat() else -panelW.toFloat())
            .setDuration(200).setInterpolator(AccelerateInterpolator()).start()
        animate().alpha(0f).setDuration(200).withEndAction { onClose() }.start()
    }
}
